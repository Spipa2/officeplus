﻿namespace ОфисПлюс
{
    partial class Card
    {
        /// <summary> 
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором компонентов

        /// <summary> 
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.labelName = new System.Windows.Forms.Label();
            this.labelType = new System.Windows.Forms.Label();
            this.labelDate = new System.Windows.Forms.Label();
            this.roundingButtonsComponent1 = new yt_DesignUI.Components.RoundingButtonsComponent(this.components);
            this.doneButton = new yt_DesignUI.yt_Button();
            this.deleteButton = new yt_DesignUI.yt_Button();
            this.label1 = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.idLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Red;
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Location = new System.Drawing.Point(-5, -4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(26, 157);
            this.panel1.TabIndex = 0;
            // 
            // labelName
            // 
            this.labelName.AutoSize = true;
            this.labelName.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelName.Location = new System.Drawing.Point(27, 9);
            this.labelName.Name = "labelName";
            this.labelName.Size = new System.Drawing.Size(112, 25);
            this.labelName.TabIndex = 1;
            this.labelName.Text = "Sample Text";
            // 
            // labelType
            // 
            this.labelType.AutoSize = true;
            this.labelType.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelType.Location = new System.Drawing.Point(28, 79);
            this.labelType.Name = "labelType";
            this.labelType.Size = new System.Drawing.Size(125, 21);
            this.labelType.TabIndex = 3;
            this.labelType.Text = "Тип: Sample Text";
            // 
            // labelDate
            // 
            this.labelDate.AutoSize = true;
            this.labelDate.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelDate.Location = new System.Drawing.Point(28, 44);
            this.labelDate.Name = "labelDate";
            this.labelDate.Size = new System.Drawing.Size(133, 21);
            this.labelDate.TabIndex = 5;
            this.labelDate.Text = "Дата: Sample Text";
            // 
            // roundingButtonsComponent1
            // 
            this.roundingButtonsComponent1.RoundingEnable = false;
            this.roundingButtonsComponent1.TargetForm = null;
            // 
            // doneButton
            // 
            this.doneButton.BackColor = System.Drawing.Color.DodgerBlue;
            this.doneButton.BackColorAdditional = System.Drawing.Color.Gray;
            this.doneButton.BackColorGradientEnabled = false;
            this.doneButton.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.doneButton.BorderColor = System.Drawing.Color.Tomato;
            this.doneButton.BorderColorEnabled = false;
            this.doneButton.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.doneButton.BorderColorOnHoverEnabled = false;
            this.doneButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.doneButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.doneButton.ForeColor = System.Drawing.Color.White;
            this.doneButton.Location = new System.Drawing.Point(176, 111);
            this.doneButton.Name = "doneButton";
            this.doneButton.RippleColor = System.Drawing.Color.Black;
            this.doneButton.RoundingEnable = false;
            this.doneButton.Size = new System.Drawing.Size(30, 30);
            this.doneButton.TabIndex = 6;
            this.doneButton.Text = "✓";
            this.doneButton.TextHover = null;
            this.doneButton.UseDownPressEffectOnClick = false;
            this.doneButton.UseRippleEffect = true;
            this.doneButton.UseVisualStyleBackColor = false;
            this.doneButton.UseZoomEffectOnHover = false;
            this.doneButton.Click += new System.EventHandler(this.cardButtonClick);
            // 
            // deleteButton
            // 
            this.deleteButton.BackColor = System.Drawing.Color.DodgerBlue;
            this.deleteButton.BackColorAdditional = System.Drawing.Color.Gray;
            this.deleteButton.BackColorGradientEnabled = false;
            this.deleteButton.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.deleteButton.BackgroundImage = global::ОфисПлюс.Properties.Resources.stock_photo_garbage_basket_pictogram_black_color_isolated;
            this.deleteButton.BorderColor = System.Drawing.Color.Tomato;
            this.deleteButton.BorderColorEnabled = false;
            this.deleteButton.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.deleteButton.BorderColorOnHoverEnabled = false;
            this.deleteButton.Cursor = System.Windows.Forms.Cursors.Hand;
            this.deleteButton.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.deleteButton.ForeColor = System.Drawing.Color.White;
            this.deleteButton.Location = new System.Drawing.Point(212, 111);
            this.deleteButton.Name = "deleteButton";
            this.deleteButton.RippleColor = System.Drawing.Color.Black;
            this.deleteButton.RoundingEnable = false;
            this.deleteButton.Size = new System.Drawing.Size(33, 30);
            this.deleteButton.TabIndex = 7;
            this.deleteButton.Text = "✕";
            this.deleteButton.TextHover = null;
            this.deleteButton.UseDownPressEffectOnClick = false;
            this.deleteButton.UseRippleEffect = true;
            this.deleteButton.UseVisualStyleBackColor = false;
            this.deleteButton.UseZoomEffectOnHover = false;
            this.deleteButton.Click += new System.EventHandler(this.cardButtonClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(28, 114);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 21);
            this.label1.TabIndex = 8;
            this.label1.Text = "Быстрое действие:";
            // 
            // idLabel
            // 
            this.idLabel.AutoSize = true;
            this.idLabel.Enabled = false;
            this.idLabel.Location = new System.Drawing.Point(352, 128);
            this.idLabel.Name = "idLabel";
            this.idLabel.Size = new System.Drawing.Size(0, 13);
            this.idLabel.TabIndex = 9;
            // 
            // Card
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.idLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.deleteButton);
            this.Controls.Add(this.doneButton);
            this.Controls.Add(this.labelDate);
            this.Controls.Add(this.labelType);
            this.Controls.Add(this.labelName);
            this.Controls.Add(this.panel1);
            this.Name = "Card";
            this.Size = new System.Drawing.Size(390, 145);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelName;
        private yt_DesignUI.Components.RoundingButtonsComponent roundingButtonsComponent1;
        private System.Windows.Forms.Label labelType;
        private System.Windows.Forms.Label labelDate;
        private yt_DesignUI.yt_Button doneButton;
        private yt_DesignUI.yt_Button deleteButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolTip toolTip1;
        private System.Windows.Forms.Label idLabel;
    }
}
