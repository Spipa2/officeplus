﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ОфисПлюс
{

    public partial class task : Form
    {
        #region ---Перетаскивание формы код---
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        private void dragForm(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
        SQLLogin sql = new SQLLogin();
        SqlConnection conn = null;

        public static int static_id;

        public task()
        {
            InitializeComponent();

            button2.Hide();
            button3.Hide();

            comboBox_type.SelectedIndex = 0;

            conn = sql.getConnection();
            SqlCommand command = new SqlCommand("SELECT staffName FROM taskStaff", conn);
            sql.openBD();
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                comboBox_staff.Items.Add(reader.GetString(0));
            }
            reader.Close();
            sql.closeBD();
            if (SQLLogin.name != "admin" && SQLLogin.name != "501-19")
            {
                comboBox_staff.Text = SQLLogin.name;
                comboBox_staff.Enabled = false;
            }
            comboBox_staff.SelectedIndex = 0;
        }

        private void zadacha_from_calendar_Load(object sender, EventArgs e)
        {
            if (static_id == -1)
            {
                try
                {
                    label1.Text = "Создание задачи";
                    dateTime_srok.Value = Convert.ToDateTime(UserControlDays.static_day + '.' + main.static_month + '.' + main.static_year);
                }
                catch
                {
                    this.Close();
                    MessageBox.Show("Ошибка: Неправильная дата. Создавать задачи можно только начиная с сегодняшнего дня");
                }
            }
            else
            {
                label1.Text = "Редактирование задачи";
                button1.Text = "Изменить";
                button2.Show();
                button3.Show();
                conn = sql.getConnection();

                SqlCommand command = new SqlCommand("SELECT taskName, taskDesc, (SELECT staffName FROM taskStaff WHERE id = taskInfoTable.taskStaff), taskDate, taskType FROM taskInfoTable WHERE id = @id", conn);
                command.Parameters.AddWithValue("@id", static_id);

                sql.openBD();
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                textbox_name.Text = reader.GetString(0);
                richTextBox_opis.Text = reader.GetString(1);
                dateTime_srok.Value = reader.GetDateTime(3);
                comboBox_type.Text = reader.GetString(4);
                comboBox_staff.Text = reader.GetString(2);
                sql.closeBD();
                reader.Close();
            }
        }

        public void button1_Click(object sender, EventArgs e) //добавление данных в бд
        {
            determineButton((sender as Button).Text);
        }

        public void determineButton(string action)
        {
            switch (action)
            {
                case "Создать":
                    createButton();
                    break;
                case "Изменить":
                    redactButton();
                    break;
                case "Выполнено":
                    doneButton();
                    break;
                case "Удалить":
                    deleteButton();
                    break;
            }
        }

        private void createButton()
        {
            try
            {
                if (dateTime_srok.Value < DateTime.Now.Date)
                {
                    MessageBox.Show("Ошибка: Невозможно создать задачу на дату раньше сегодняшней.");
                }
                else
                {
                    conn = sql.getConnection();
                    SqlCommand cmd = new SqlCommand("INSERT INTO taskInfoTable (taskName, taskDesc, taskStaff, taskDate, taskType, taskComplete) " +
                        "VALUES(@name, @desc, (SELECT id FROM taskStaff WHERE staffName = @staff), @date, @type, 0)", conn);
                    cmd.Parameters.AddWithValue("@name", textbox_name.Text);
                    cmd.Parameters.AddWithValue("@desc", richTextBox_opis.Text);
                    cmd.Parameters.AddWithValue("@staff", comboBox_staff.Text);
                    cmd.Parameters.AddWithValue("@date", dateTime_srok.Value);
                    cmd.Parameters.AddWithValue("@type", comboBox_type.Text);
                    sql.openBD();
                    cmd.ExecuteNonQuery();
                    sql.closeBD();
                    this.Close();
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Ошибка: " + a.Message);
            }
        }

        private void redactButton()
        {
            try
            {
                conn = sql.getConnection();
                SqlCommand cmd = new SqlCommand("UPDATE taskInfoTable SET taskName = @name, taskDesc = @desc, " +
                    "taskStaff = (SELECT id FROM taskStaff WHERE staffName = @staff), taskDate = @date, taskType = @type WHERE id = @id", conn);
                cmd.Parameters.AddWithValue("@name", textbox_name.Text);
                cmd.Parameters.AddWithValue("@desc", richTextBox_opis.Text);
                cmd.Parameters.AddWithValue("@staff", comboBox_staff.Text);
                cmd.Parameters.AddWithValue("@date", dateTime_srok.Value);
                cmd.Parameters.AddWithValue("@type", comboBox_type.Text);
                cmd.Parameters.AddWithValue("@id", static_id);
                sql.openBD();
                cmd.ExecuteNonQuery();
                sql.closeBD();
                this.Close();
            }
            catch (Exception a)
            {
                MessageBox.Show("Ошибка: " + a.Message);
            }
        }

        public void doneButton()
        {
            try
            {
                var logout = MessageBox.Show("Вы точно хотите завершить задачу?", "Выполнение задачи", MessageBoxButtons.YesNo);
                if (logout == DialogResult.Yes)
                {
                    conn = sql.getConnection();
                    SqlCommand cmd = new SqlCommand("UPDATE taskInfoTable SET taskComplete = 1 WHERE id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", static_id);
                    sql.openBD();
                    cmd.ExecuteNonQuery();
                    sql.closeBD();
                    this.Close();
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Ошибка: " + a.Message);
            }
        }

        public void deleteButton()
        {
            try
            {
                var logout = MessageBox.Show("Вы точно хотите удалить задачу?", "Удаление задачи", MessageBoxButtons.YesNo);
                if (logout == DialogResult.Yes)
                {
                    conn = sql.getConnection();
                    SqlCommand cmd = new SqlCommand("DELETE FROM taskInfoTable WHERE id = @id", conn);
                    cmd.Parameters.AddWithValue("@id", static_id);
                    sql.openBD();
                    cmd.ExecuteNonQuery();
                    sql.closeBD();
                    this.Close();
                }
            }
            catch (Exception a)
            {
                MessageBox.Show("Ошибка: " + a.Message);
            }
        }

        private void yt_Button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
