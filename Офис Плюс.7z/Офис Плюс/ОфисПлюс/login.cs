﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Drawing.Drawing2D;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using Microsoft.Toolkit.Uwp.Notifications;

namespace ОфисПлюс
{
    public partial class login : Form
    {
        #region ---Перетаскивание формы код---
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        private void dragForm(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion
        public login()
        {
            InitializeComponent();

            MaximizeBox = false;
            timer1.Interval = 60000;
            timer1.Tick += Timer1_Tick;
            timer1.Start();
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
            #region ---beba
            new ToastContentBuilder()
    .AddArgument("action", "viewConversation")
    .AddArgument("conversationId", 9813)
    .AddText("10 years in the joint made you a fucking pussy")
    .AddText("Bring your shit, Kazuma!")
    .Show();
            #endregion
        }

        private void login_Load(object sender, EventArgs e)
        {
            this.ActiveControl = label1;
            loginer.Text = "Введите логин";
            loginer.ForeColor = Color.DarkGray;

            #region ---Форма---
            this.FormBorderStyle = FormBorderStyle.None;

            Panel pnlTop = new Panel() { Height = 1, Dock = DockStyle.Top, BackColor = Color.Black };
            this.Controls.Add(pnlTop);

            Panel pnlRight = new Panel() { Width = 1, Dock = DockStyle.Right, BackColor = Color.Black };
            this.Controls.Add(pnlRight);

            Panel pnlBottom = new Panel() { Height = 1, Dock = DockStyle.Bottom, BackColor = Color.Black };
            this.Controls.Add(pnlBottom);

            Panel pnlLeft = new Panel() { Width = 1, Dock = DockStyle.Left, BackColor = Color.Black };
            this.Controls.Add(pnlLeft);
            #endregion
        }

        public void button1_Click(object sender, EventArgs e)
        {
            SQLLogin.name = loginer.Text;
            string connectSQL = @"Data Source = WIN-42J38MOEN1J\SQLEXPRESS02;Initial Catalog = pep; User ID = " + SQLLogin.name + "; Password = " + passworder.Text;

            //открытие бд и проверка авторизации
            SqlConnection conn = new SqlConnection(connectSQL);
            try
            {
                conn.Open();
                MessageBox.Show("Успешно подключено");
                SQLLogin.connect = connectSQL;
                conn.Close();
                main f = new main();
                f.Show();
                this.Hide();
            }
            catch (Exception a)
            {
                MessageBox.Show("Ошибка: " + a.Message);
            }
        }
        private void login_FormClosed(object sender, EventArgs e)
        {
            Application.Exit();
        }

        // Исчезающий текст и перекраска из серого в черный и обратно
        #region ---Логин---
        private void loginer_Enter(object sender, EventArgs e)
        {
            if (loginer.Text == "Введите логин")
            {
                loginer.Text = "";
                loginer.ForeColor = Color.Black;
            }
        }
        private void loginer_Leave(object sender, EventArgs e)
        {
            if (loginer.Text == "")
            {
                loginer.Text = "Введите логин";
                loginer.ForeColor = Color.DarkGray;
            }
        }
        #endregion

        #region ---Пароль---
        private void passworder_Enter(object sender, EventArgs e)
        {
            label4.Hide();
            passworder.Focus();
        }

        private void passworder_Leave(object sender, EventArgs e)
        {
            if (passworder.Text == "")
            {
                label4.Show();
            }
        }
        #endregion
    }
}
