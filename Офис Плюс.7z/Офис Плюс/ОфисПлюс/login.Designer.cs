﻿using System.Drawing.Drawing2D;
using System.Drawing;
using System.Windows.Forms;
using System.Net;
using System;

namespace ОфисПлюс
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }


        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.roundingButtonsComponent1 = new yt_DesignUI.Components.RoundingButtonsComponent(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.loginer = new ОфисПлюс.CeLearningTextbox();
            this.fake = new ОфисПлюс.CeLearningTextbox();
            this.button1 = new yt_DesignUI.yt_Button();
            this.passworder = new System.Windows.Forms.MaskedTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.yt_Button1 = new yt_DesignUI.yt_Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // roundingButtonsComponent1
            // 
            this.roundingButtonsComponent1.NestedContainers = false;
            this.roundingButtonsComponent1.RoundingEnable = true;
            this.roundingButtonsComponent1.TargetForm = this;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(12, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 21);
            this.label1.TabIndex = 0;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.label2.Location = new System.Drawing.Point(12, 92);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 21);
            this.label2.TabIndex = 1;
            this.label2.Text = "Пароль";
            // 
            // loginer
            // 
            this.loginer.BackColor = System.Drawing.Color.Transparent;
            this.loginer.Br = System.Drawing.Color.White;
            this.loginer.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.loginer.ForeColor = System.Drawing.Color.Black;
            this.loginer.Location = new System.Drawing.Point(86, 45);
            this.loginer.Name = "loginer";
            this.loginer.Size = new System.Drawing.Size(233, 33);
            this.loginer.TabIndex = 1;
            this.loginer.Enter += new System.EventHandler(this.loginer_Enter);
            this.loginer.Leave += new System.EventHandler(this.loginer_Leave);
            // 
            // fake
            // 
            this.fake.BackColor = System.Drawing.Color.Transparent;
            this.fake.Br = System.Drawing.Color.White;
            this.fake.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.fake.ForeColor = System.Drawing.Color.Black;
            this.fake.Location = new System.Drawing.Point(86, 85);
            this.fake.Name = "fake";
            this.fake.Size = new System.Drawing.Size(233, 33);
            this.fake.TabIndex = 3;
            this.fake.TabStop = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DodgerBlue;
            this.button1.BackColorAdditional = System.Drawing.Color.Gray;
            this.button1.BackColorGradientEnabled = false;
            this.button1.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.button1.BorderColor = System.Drawing.Color.Tomato;
            this.button1.BorderColorEnabled = false;
            this.button1.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.button1.BorderColorOnHoverEnabled = false;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(74, 133);
            this.button1.Name = "button1";
            this.button1.RippleColor = System.Drawing.Color.Black;
            this.button1.Rounding = 93;
            this.button1.RoundingEnable = true;
            this.button1.Size = new System.Drawing.Size(185, 30);
            this.button1.TabIndex = 7;
            this.button1.TabStop = false;
            this.button1.Text = "Авторизация";
            this.button1.TextHover = null;
            this.button1.UseDownPressEffectOnClick = false;
            this.button1.UseRippleEffect = true;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.UseZoomEffectOnHover = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // passworder
            // 
            this.passworder.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.passworder.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.passworder.Location = new System.Drawing.Point(96, 90);
            this.passworder.Name = "passworder";
            this.passworder.PasswordChar = '*';
            this.passworder.Size = new System.Drawing.Size(212, 22);
            this.passworder.TabIndex = 2;
            this.passworder.Enter += new System.EventHandler(this.passworder_Enter);
            this.passworder.Leave += new System.EventHandler(this.passworder_Leave);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Enabled = false;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.DarkGray;
            this.label4.Location = new System.Drawing.Point(93, 90);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(123, 21);
            this.label4.TabIndex = 10;
            this.label4.Text = "Введите пароль";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.yt_Button1);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(-3, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(338, 40);
            this.panel1.TabIndex = 11;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragForm);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(3, 8);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 25);
            this.label3.TabIndex = 13;
            this.label3.Text = "Авторизация";
            // 
            // yt_Button1
            // 
            this.yt_Button1.BackColor = System.Drawing.Color.SteelBlue;
            this.yt_Button1.BackColorAdditional = System.Drawing.Color.Gray;
            this.yt_Button1.BackColorGradientEnabled = false;
            this.yt_Button1.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.yt_Button1.BorderColor = System.Drawing.Color.Tomato;
            this.yt_Button1.BorderColorEnabled = false;
            this.yt_Button1.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.yt_Button1.BorderColorOnHoverEnabled = false;
            this.yt_Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.yt_Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yt_Button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.yt_Button1.ForeColor = System.Drawing.Color.White;
            this.yt_Button1.Location = new System.Drawing.Point(301, 3);
            this.yt_Button1.Name = "yt_Button1";
            this.yt_Button1.RippleColor = System.Drawing.Color.Black;
            this.yt_Button1.RoundingEnable = false;
            this.yt_Button1.Size = new System.Drawing.Size(35, 38);
            this.yt_Button1.TabIndex = 12;
            this.yt_Button1.Text = "X";
            this.yt_Button1.TextHover = null;
            this.yt_Button1.UseDownPressEffectOnClick = false;
            this.yt_Button1.UseRippleEffect = true;
            this.yt_Button1.UseVisualStyleBackColor = false;
            this.yt_Button1.UseZoomEffectOnHover = false;
            this.yt_Button1.Click += new System.EventHandler(this.login_FormClosed);
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(332, 175);
            this.ControlBox = false;
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.passworder);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.fake);
            this.Controls.Add(this.loginer);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(3663123, 21312);
            this.MinimumSize = new System.Drawing.Size(300, 160);
            this.Name = "login";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.login_FormClosed);
            this.Load += new System.EventHandler(this.login_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private yt_DesignUI.Components.RoundingButtonsComponent roundingButtonsComponent1;
        private Label label4;
        private MaskedTextBox passworder;
        private yt_DesignUI.yt_Button button1;
        private CeLearningTextbox fake;
        private CeLearningTextbox loginer;
        private Label label2;
        private Label label1;
        private Panel panel1;
        private yt_DesignUI.yt_Button yt_Button1;
        private Label label3;
        private Timer timer1;
    }
}