﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОфисПлюс
{
    public class RoundedButton : Button
    {
        public RoundedButton()
        {
            FlatStyle = FlatStyle.Flat;
            FlatAppearance.BorderSize = 1;
            FlatAppearance.BorderColor = Color.DodgerBlue;
            FlatAppearance.MouseDownBackColor = Color.SteelBlue;

            // Задаем радиус закругления углов
            BorderRadius = 10;
        }

        public int BorderRadius { get; set; }

        protected override void OnPaint(PaintEventArgs pevent)
        {
            base.OnPaint(pevent);
            GraphicsPath path = new GraphicsPath();
            int radius = BorderRadius;
            Rectangle bounds = new Rectangle(0, 0, Width, Height);

            // Закругляем углы
            path.AddArc(bounds.X, bounds.Y, radius * 2, radius * 2, 180, 90);
            path.AddArc(bounds.X + bounds.Width - 2 * radius, bounds.Y, radius * 2, radius * 2, 270, 90);
            path.AddArc(bounds.X + bounds.Width - 2 * radius, bounds.Y + bounds.Height - 2 * radius, radius * 2, radius * 2, 0, 90);
            path.AddArc(bounds.X, bounds.Y + bounds.Height - 2 * radius, radius * 2, radius * 2, 90, 90);

            path.CloseFigure();
            Region = new Region(path);
        }
    }
}
