﻿using System;
using System.Collections.Generic;
using System.Drawing.Drawing2D;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОфисПлюс
{
    public class CeLearningrichRichTextBox : Control
    {
        private int radius = 15;
        private RichTextBox richTextBox = new RichTextBox();
        private GraphicsPath shape;
        private GraphicsPath innerRect;
        private Color br;
        
        public CeLearningrichRichTextBox()
        {
            base.SetStyle(ControlStyles.SupportsTransparentBackColor, true);
            base.SetStyle(ControlStyles.UserPaint, true);
            base.SetStyle(ControlStyles.ResizeRedraw, true);
            this.richTextBox.Parent = this;
            base.Controls.Add(this.richTextBox);
            this.richTextBox.BorderStyle = BorderStyle.None;
            richTextBox.Font = this.Font;
            this.BackColor = Color.Transparent;
            this.ForeColor = Color.Black;
            this.br = Color.White;
            richTextBox.BackColor = this.br;
            this.Text = null;
            this.Font = new Font("Century Gothic", 12f);
            base.Size = new Size(0x87, 0x21);
            this.DoubleBuffered = true;
            richTextBox.KeyDown += new KeyEventHandler(richTextBox_KeyDown);
            richTextBox.TextChanged += new EventHandler(richTextBox_TextChanged);
            richTextBox.MouseDoubleClick += new MouseEventHandler(richTextBox_MouseDoubleClick);
        }

        private void richTextBox_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                richTextBox.SelectAll();
            }
        }

        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            this.Text = richTextBox.Text;
        }

        private void richTextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control && (e.KeyCode == Keys.A))
            {
                richTextBox.SelectionStart = 0;
                richTextBox.SelectionLength = this.Text.Length;
            }
        }

        protected override void OnFontChanged(EventArgs e)
        {
            base.OnFontChanged(e);
            richTextBox.Font = this.Font;
            base.Invalidate();
        }

        protected override void OnForeColorChanged(EventArgs e)
        {
            base.OnForeColorChanged(e);
            richTextBox.ForeColor = this.ForeColor;
            base.Invalidate();
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            this.shape = new MyRectangle((float)base.Width, (float)base.Height, (float)this.radius, 0f, 0f).Path;
            this.innerRect = new MyRectangle(base.Width - 0.5f, base.Height - 0.5f, (float)this.radius, 0.5f, 0.5f).Path;
            if (richTextBox.Height >= (base.Height - 4))
            {
                base.Height = richTextBox.Height + 4;
            }
            richTextBox.Location = new Point(this.radius - 5, (base.Height / 12) - (richTextBox.Font.Height / 12));
            richTextBox.Width = base.Width - ((int)(this.radius * 1.5));
            e.Graphics.SmoothingMode = ((SmoothingMode)SmoothingMode.HighQuality);
            Bitmap bitmap = new Bitmap(base.Width, base.Height);
            Graphics graphics = Graphics.FromImage(bitmap);
            e.Graphics.DrawPath(Pens.Gray, this.shape);
            using (SolidBrush brush = new SolidBrush(this.br))
            {
                e.Graphics.FillPath((Brush)brush, this.innerRect);
            }
            Trans.MakeTransparent(this, e.Graphics);
            base.OnPaint(e);
        }

        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);
            richTextBox.Text = this.Text;
        }

        public void SelectAll()
        {
            richTextBox.SelectAll();
        }

        public Color Br
        {
            get =>
                this.br;
            set
            {
                this.br = value;
                if (this.br != Color.Transparent)
                {
                    richTextBox.BackColor = this.br;
                }
                base.Invalidate();
            }
        }

        public override Color BackColor
        {
            get => base.BackColor;
            set => base.BackColor = Color.Transparent;
        }
    }
}
