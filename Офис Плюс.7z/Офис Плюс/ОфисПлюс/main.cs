﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОфисПлюс
{
    public partial class main : Form
    {
        #region ---Перетаскивание формы код---
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        public static extern bool ReleaseCapture();

        private void dragForm(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0);
            }
        }
        #endregion

        int month, year;
        public static int static_month, static_year;
        public static string selectedDate = DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day;
        SQLLogin sql = new SQLLogin();

        public main()
        {
            InitializeComponent();
        }

        private void _10yearsinthejointmadeyouafuckinpussy_Load(object sender, EventArgs e)
        {
            if (taskCards.Controls.Count > 1)
            {
                label10.Hide();
            }
            if (taskLines.Controls.Count > 1)
            {
                label11.Hide();
            }
            displayDays("load");
            createLines();
            createCards();
            labelGreet.Text = "Здравствуйте, " + SQLLogin.name + "!";
            #region ---Форма---
            this.FormBorderStyle = FormBorderStyle.None;

            Panel pnlTop = new Panel() { Height = 1, Dock = DockStyle.Top, BackColor = Color.Black };
            this.Controls.Add(pnlTop);

            Panel pnlRight = new Panel() { Width = 1, Dock = DockStyle.Right, BackColor = Color.Black };
            this.Controls.Add(pnlRight);

            Panel pnlBottom = new Panel() { Height = 1, Dock = DockStyle.Bottom, BackColor = Color.Black };
            this.Controls.Add(pnlBottom);

            Panel pnlLeft = new Panel() { Width = 1, Dock = DockStyle.Left, BackColor = Color.Black };
            this.Controls.Add(pnlLeft);
            #endregion
        }

        // Календарь

        public void displayDays(string Button)
        {
            switch (Button)
            {
                case "load":
                    month = DateTime.Now.Month;
                    year = DateTime.Now.Year;
                    break;
                case "btnnext":
                    daycontainer.Controls.Clear();
                    month++;

                    if (month == 13)
                    {
                        month = 1;
                        year++;
                    }
                    break;
                case "btnprevious":
                    daycontainer.Controls.Clear();
                    month--;

                    if (month == 0)
                    {
                        month = 12;
                        year--;
                    }
                    break;
            }

            string monthname = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
            lbdate.Text = monthname + ", " + year;

            static_month = month;
            static_year = year;

            DateTime startofthemonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int daysoftheweek = Convert.ToInt32(startofthemonth.DayOfWeek.ToString("d"));
            if (daysoftheweek == 0)
            {
                daysoftheweek = 7;
            }

            for (int i = 1; i < daysoftheweek; i++)
            {
                UserControlBlank ucblank = new UserControlBlank();
                daycontainer.Controls.Add(ucblank);
            }

            SqlConnection connection = sql.getConnection();
            for (int i = 1; i <= days; i++)
            {
                SqlCommand command = new SqlCommand("SELECT taskType FROM taskInfoTable WHERE taskDate = @date", connection);
                command.Parameters.AddWithValue("@date", static_year + "-" + static_month + "-" + i);
                sql.openBD();
                SqlDataReader reader = command.ExecuteReader();

                UserControlDays ucdays = new UserControlDays();
                ucdays.days(i);
                ucdays.Name = "date" + i.ToString();
                ucdays.Click += selectButton;

                while (reader.Read())
                {
                    ucdays.colorHighlight(reader.GetString(0));
                }
                sql.closeBD();
                daycontainer.Controls.Add(ucdays);
                if (static_year == DateTime.Now.Year)
                {
                    if (static_month == DateTime.Now.Month)
                    {
                        if (i == DateTime.Now.Day)
                        {
                            ucdays.BackColor = Color.Red;
                        }
                    }
                }
            }
        }

        private void calendarButton(object sender, EventArgs e)
        {
            displayDays((sender as Button).Name);
        }

        public void selectButton(object sender, EventArgs e)
        {
            for (int i = 1; i <= DateTime.DaysInMonth(static_year, static_month); i++)
            {
                if (daycontainer.Controls["date" + i.ToString()].BackColor == Color.LightBlue)
                {
                    daycontainer.Controls["date" + i.ToString()].BackColor = Color.LightGray;
                }
                if (static_year == DateTime.Now.Year)
                {
                    if (static_month == DateTime.Now.Month)
                    {
                        if (i == DateTime.Now.Day)
                        {
                            daycontainer.Controls["date" + i.ToString()].BackColor = Color.Red;
                        }
                    }
                }
            }
            daycontainer.Controls["date" + UserControlDays.static_day].BackColor = Color.LightBlue;
            selectedDate = static_year + "-" + static_month + "-" + UserControlDays.static_day;
            createCards();
        }

        //Карточки
        public void createCards()
        {
            taskCards.Controls.Clear();

            SqlConnection connection = sql.getConnection();
            SqlCommand command = new SqlCommand("SELECT * FROM taskInfoTable WHERE taskDate = @date", connection);
            command.Parameters.AddWithValue("@date", selectedDate);

            sql.openBD();

            int cardCounter = 1;

            SqlDataReader reader = command.ExecuteReader();

            while (reader.Read())
            {
                Card card = new Card();
                card.values(reader.GetInt64(0), reader.GetString(1), reader.GetDateTime(4), reader.GetString(5));
                card.Name = reader.GetInt64(0).ToString();
                if (reader.GetBoolean(6) == true)
                {
                    card.BackColor = Color.WhiteSmoke;
                    card.Enabled = false;
                }
                card.Click += Card_Click;
                taskCards.Controls.Add(card);
                cardCounter += 1;
                if (cardCounter > 1)
                {
                    label10.Hide();
                }
            }
            reader.Close();
            sql.closeBD();
        }

        private void Card_Click(object sender, EventArgs e)
        {
            zadacha_Show(Convert.ToInt32((sender as Card).Name));
        }

        //Строчки
        public void createLines()
        {
            taskLines.Controls.Clear();

            SqlConnection connection = sql.getConnection();
            SqlCommand command = new SqlCommand("SELECT id, taskName, taskType, taskDate, taskComplete FROM taskInfoTable WHERE taskDate = @today OR taskDate = @tomorrow", connection);
            command.Parameters.AddWithValue("@today", DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day);
            command.Parameters.AddWithValue("@tomorrow", DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + (DateTime.Now.Day + 1));

            Label today = new Label();
            today.Text = "Сегодня: ";
            taskLines.Controls.Add(today);

            sql.openBD();
            SqlDataReader reader = command.ExecuteReader();
            bool check = false;
            while (reader.Read())
            {
                if (DateTime.Now.Date.AddDays(1) == reader.GetDateTime(3) && check == false)
                {
                    Label tomorrow = new Label();
                    tomorrow.Text = "Завтра: ";
                    taskLines.Controls.Add(tomorrow);
                    check = true;
                }
                Lines line = new Lines();
                line.Name = reader.GetInt64(0).ToString();
                line.values(reader.GetString(1), reader.GetString(2));
                line.Click += Lines_Click;
                if (reader.GetBoolean(4) == true)
                {
                    line.BackColor = Color.WhiteSmoke;
                    line.Enabled = false;
                }
                taskLines.Controls.Add(line);
            }
            reader.Close();
            sql.closeBD();
        }
        private void Lines_Click(object sender, EventArgs e)
        {
            zadacha_Show(Convert.ToInt32((sender as Lines).Name));
        }

        //Кнопки
        private void yt_Button1_Click(object sender, EventArgs e)
        {
            var logout = MessageBox.Show("Вы точно хотите выйти?", "Выход из аккаунта", MessageBoxButtons.YesNo);
            if (logout == DialogResult.Yes)
            {
                login login = new login();
                login.Show();
                this.Close();
            }
        }
        private void yt_Button5_Click(object sender, EventArgs e)
        {
            var exit = MessageBox.Show("Завершить работу?", "Завершение работы", MessageBoxButtons.YesNo);
            if (exit == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        private void createTask_Click(object sender, EventArgs e)
        {
            zadacha_Show(-1);
        }
        private void zadacha_Show(int id)
        {
            task t = new task();
            task.static_id = id;
            t.Owner = this;
            t.ShowDialog();
            createCards();
            createLines();
        }
    }
}