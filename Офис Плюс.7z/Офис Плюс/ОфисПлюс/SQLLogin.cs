﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ОфисПлюс
{
    internal class SQLLogin
    {
        public static string name { get; set; }
        public static string connect { get; set; }

        SqlConnection connection = new SqlConnection();

        public void openBD()
        {
            connection.ConnectionString = connect;
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }
        public void closeBD()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
        public SqlConnection getConnection()
        {
            connection.ConnectionString = connect;
            return connection;
        }
    }
}

