﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОфисПлюс
{
    public partial class UserControlDays : UserControl
    {
        public static string static_day;

        public UserControlDays()
        {
            InitializeComponent();
        }
        
        public void days(int numday)
        {
            label1.Text = numday + "";
        }

        private void UserControlDays_Click(object sender, EventArgs e)
        {
            static_day = label1.Text;
        }
        public void colorHighlight(string taskType)
        {
            Color color = new Color();
            switch (taskType)
            {
                case "Встреча":
                    color = Color.LightGreen;
                    break;
                case "Совещание":
                    color = Color.Orange;
                    break;
                case "Презентация":
                    color = Color.Red;
                    break;
                case "Выставка":
                    color = Color.Blue;
                    break;
                case "Съезд / Форум":
                    color = Color.LightBlue;
                    break;
                case "Конференция":
                    color = Color.Green;
                    break;
                case "Конгресс":
                    color = Color.DarkRed;
                    break;
                case "Переговоры":
                    color = Color.Gold;
                    break;
                case "Тим - билд":
                    color = Color.DarkCyan;
                    break;
                case "Прочее":
                    color = Color.DarkGray;
                    break;
            }
            Label colorLabel = new Label();
            colorLabel.BackColor = color;
            colorLabel.Size = new Size(10, 15);
            colorLabel.Margin = new Padding(0);
            flowLayoutPanel1.Controls.Add(colorLabel);
        }
    }
}
