﻿namespace ОфисПлюс
{
    partial class task
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox_staff = new System.Windows.Forms.ComboBox();
            this.comboBox_type = new System.Windows.Forms.ComboBox();
            this.dateTime_srok = new System.Windows.Forms.DateTimePicker();
            this.label10 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.yt_Button1 = new yt_DesignUI.yt_Button();
            this.button2 = new yt_DesignUI.yt_Button();
            this.button3 = new yt_DesignUI.yt_Button();
            this.button1 = new yt_DesignUI.yt_Button();
            this.richTextBox_opis = new ОфисПлюс.CeLearningrichRichTextBox2();
            this.textbox_name = new ОфисПлюс.CeLearningTextbox();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(451, 311);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(126, 21);
            this.label3.TabIndex = 50;
            this.label3.Text = "Кому поручить?";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(228, 311);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 21);
            this.label5.TabIndex = 49;
            this.label5.Text = "Тип";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 311);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(138, 21);
            this.label6.TabIndex = 48;
            this.label6.Text = "Срок выполнения";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(12, 104);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(135, 21);
            this.label9.TabIndex = 47;
            this.label9.Text = "Описание задачи";
            // 
            // comboBox_staff
            // 
            this.comboBox_staff.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_staff.FormattingEnabled = true;
            this.comboBox_staff.Location = new System.Drawing.Point(455, 338);
            this.comboBox_staff.Name = "comboBox_staff";
            this.comboBox_staff.Size = new System.Drawing.Size(200, 29);
            this.comboBox_staff.TabIndex = 45;
            // 
            // comboBox_type
            // 
            this.comboBox_type.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.comboBox_type.FormattingEnabled = true;
            this.comboBox_type.Items.AddRange(new object[] {
            "Встреча",
            "Совещание",
            "Презентация",
            "Выставка",
            "Съезд/Форум",
            "Конференция",
            "Конгресс",
            "Переговоры",
            "Тим-билд",
            "Прочее"});
            this.comboBox_type.Location = new System.Drawing.Point(232, 338);
            this.comboBox_type.Name = "comboBox_type";
            this.comboBox_type.Size = new System.Drawing.Size(200, 29);
            this.comboBox_type.TabIndex = 44;
            // 
            // dateTime_srok
            // 
            this.dateTime_srok.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.dateTime_srok.Location = new System.Drawing.Point(12, 338);
            this.dateTime_srok.Name = "dateTime_srok";
            this.dateTime_srok.Size = new System.Drawing.Size(200, 29);
            this.dateTime_srok.TabIndex = 43;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(12, 44);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(132, 21);
            this.label10.TabIndex = 42;
            this.label10.Text = "Название задачи";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.yt_Button1);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(-14, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(710, 40);
            this.panel1.TabIndex = 53;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragForm);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(14, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 25);
            this.label1.TabIndex = 13;
            this.label1.Text = "Создание задачи";
            // 
            // yt_Button1
            // 
            this.yt_Button1.BackColor = System.Drawing.Color.SteelBlue;
            this.yt_Button1.BackColorAdditional = System.Drawing.Color.Gray;
            this.yt_Button1.BackColorGradientEnabled = false;
            this.yt_Button1.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.yt_Button1.BorderColor = System.Drawing.Color.Tomato;
            this.yt_Button1.BorderColorEnabled = false;
            this.yt_Button1.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.yt_Button1.BorderColorOnHoverEnabled = false;
            this.yt_Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.yt_Button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yt_Button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.yt_Button1.ForeColor = System.Drawing.Color.White;
            this.yt_Button1.Location = new System.Drawing.Point(672, 6);
            this.yt_Button1.Name = "yt_Button1";
            this.yt_Button1.RippleColor = System.Drawing.Color.Black;
            this.yt_Button1.RoundingEnable = false;
            this.yt_Button1.Size = new System.Drawing.Size(35, 35);
            this.yt_Button1.TabIndex = 12;
            this.yt_Button1.Text = "X";
            this.yt_Button1.TextHover = null;
            this.yt_Button1.UseDownPressEffectOnClick = false;
            this.yt_Button1.UseRippleEffect = true;
            this.yt_Button1.UseVisualStyleBackColor = false;
            this.yt_Button1.UseZoomEffectOnHover = false;
            this.yt_Button1.Click += new System.EventHandler(this.yt_Button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DodgerBlue;
            this.button2.BackColorAdditional = System.Drawing.Color.Gray;
            this.button2.BackColorGradientEnabled = false;
            this.button2.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.button2.BorderColor = System.Drawing.Color.Tomato;
            this.button2.BorderColorEnabled = false;
            this.button2.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.button2.BorderColorOnHoverEnabled = false;
            this.button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.ForeColor = System.Drawing.Color.White;
            this.button2.Location = new System.Drawing.Point(232, 380);
            this.button2.Name = "button2";
            this.button2.RippleColor = System.Drawing.Color.Black;
            this.button2.Rounding = 93;
            this.button2.RoundingEnable = true;
            this.button2.Size = new System.Drawing.Size(185, 30);
            this.button2.TabIndex = 57;
            this.button2.Text = "Выполнено";
            this.button2.TextHover = null;
            this.button2.UseDownPressEffectOnClick = false;
            this.button2.UseRippleEffect = true;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.UseZoomEffectOnHover = false;
            this.button2.Click += new System.EventHandler(this.button1_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DodgerBlue;
            this.button3.BackColorAdditional = System.Drawing.Color.Gray;
            this.button3.BackColorGradientEnabled = false;
            this.button3.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.button3.BorderColor = System.Drawing.Color.Tomato;
            this.button3.BorderColorEnabled = false;
            this.button3.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.button3.BorderColorOnHoverEnabled = false;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(454, 380);
            this.button3.Name = "button3";
            this.button3.RippleColor = System.Drawing.Color.Black;
            this.button3.Rounding = 93;
            this.button3.RoundingEnable = true;
            this.button3.Size = new System.Drawing.Size(185, 30);
            this.button3.TabIndex = 56;
            this.button3.Text = "Удалить";
            this.button3.TextHover = null;
            this.button3.UseDownPressEffectOnClick = false;
            this.button3.UseRippleEffect = true;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.UseZoomEffectOnHover = false;
            this.button3.Click += new System.EventHandler(this.button1_Click);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DodgerBlue;
            this.button1.BackColorAdditional = System.Drawing.Color.Gray;
            this.button1.BackColorGradientEnabled = false;
            this.button1.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.button1.BorderColor = System.Drawing.Color.Tomato;
            this.button1.BorderColorEnabled = false;
            this.button1.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.button1.BorderColorOnHoverEnabled = false;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(20, 380);
            this.button1.Name = "button1";
            this.button1.RippleColor = System.Drawing.Color.Black;
            this.button1.Rounding = 93;
            this.button1.RoundingEnable = true;
            this.button1.Size = new System.Drawing.Size(185, 30);
            this.button1.TabIndex = 52;
            this.button1.Text = "Создать";
            this.button1.TextHover = null;
            this.button1.UseDownPressEffectOnClick = false;
            this.button1.UseRippleEffect = true;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.UseZoomEffectOnHover = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // richTextBox_opis
            // 
            this.richTextBox_opis.BackColor = System.Drawing.Color.Transparent;
            this.richTextBox_opis.Br = System.Drawing.Color.White;
            this.richTextBox_opis.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.richTextBox_opis.ForeColor = System.Drawing.Color.Black;
            this.richTextBox_opis.Location = new System.Drawing.Point(11, 127);
            this.richTextBox_opis.Margin = new System.Windows.Forms.Padding(2);
            this.richTextBox_opis.Name = "richTextBox_opis";
            this.richTextBox_opis.Size = new System.Drawing.Size(649, 181);
            this.richTextBox_opis.TabIndex = 51;
            // 
            // textbox_name
            // 
            this.textbox_name.BackColor = System.Drawing.Color.Transparent;
            this.textbox_name.Br = System.Drawing.Color.White;
            this.textbox_name.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textbox_name.ForeColor = System.Drawing.Color.Black;
            this.textbox_name.Location = new System.Drawing.Point(12, 67);
            this.textbox_name.Name = "textbox_name";
            this.textbox_name.Size = new System.Drawing.Size(647, 34);
            this.textbox_name.TabIndex = 46;
            // 
            // task
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(691, 423);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.richTextBox_opis);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.textbox_name);
            this.Controls.Add(this.comboBox_staff);
            this.Controls.Add(this.comboBox_type);
            this.Controls.Add(this.dateTime_srok);
            this.Controls.Add(this.label10);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.HelpButton = true;
            this.MaximumSize = new System.Drawing.Size(68632, 27523);
            this.MinimumSize = new System.Drawing.Size(686, 275);
            this.Name = "task";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Добавление задачи";
            this.Load += new System.EventHandler(this.zadacha_from_calendar_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private yt_DesignUI.yt_Button button1;
        private CeLearningrichRichTextBox2 richTextBox_opis;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label9;
        private CeLearningTextbox textbox_name;
        private System.Windows.Forms.ComboBox comboBox_staff;
        private System.Windows.Forms.ComboBox comboBox_type;
        private System.Windows.Forms.DateTimePicker dateTime_srok;
        private System.Windows.Forms.Label label10;
        private yt_DesignUI.yt_Button yt_Button1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private yt_DesignUI.yt_Button button2;
        private yt_DesignUI.yt_Button button3;
    }

}