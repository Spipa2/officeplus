﻿namespace ОфисПлюс
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.daycontainer = new System.Windows.Forms.FlowLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbdate = new System.Windows.Forms.Label();
            this.taskCards = new System.Windows.Forms.FlowLayoutPanel();
            this.label10 = new System.Windows.Forms.Label();
            this.taskLines = new System.Windows.Forms.FlowLayoutPanel();
            this.label11 = new System.Windows.Forms.Label();
            this.labelGreet = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.yt_Button2 = new yt_DesignUI.yt_Button();
            this.yt_Button1 = new yt_DesignUI.yt_Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.createTask = new yt_DesignUI.yt_Button();
            this.btnnext = new yt_DesignUI.yt_Button();
            this.btnprevious = new yt_DesignUI.yt_Button();
            this.taskCards.SuspendLayout();
            this.taskLines.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // daycontainer
            // 
            this.daycontainer.Location = new System.Drawing.Point(724, 117);
            this.daycontainer.Name = "daycontainer";
            this.daycontainer.Size = new System.Drawing.Size(475, 407);
            this.daycontainer.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(737, 86);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(39, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "ПН";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(807, 86);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 25);
            this.label2.TabIndex = 2;
            this.label2.Text = "ВТ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(872, 86);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(35, 25);
            this.label3.TabIndex = 3;
            this.label3.Text = "СР";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(1070, 86);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 25);
            this.label4.TabIndex = 6;
            this.label4.Text = "СБ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(1002, 86);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 25);
            this.label5.TabIndex = 5;
            this.label5.Text = "ПТ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.Location = new System.Drawing.Point(936, 86);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 25);
            this.label6.TabIndex = 4;
            this.label6.Text = "ЧТ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.Location = new System.Drawing.Point(1135, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(35, 25);
            this.label7.TabIndex = 7;
            this.label7.Text = "ВС";
            // 
            // lbdate
            // 
            this.lbdate.AutoSize = true;
            this.lbdate.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbdate.Location = new System.Drawing.Point(908, 48);
            this.lbdate.Name = "lbdate";
            this.lbdate.Size = new System.Drawing.Size(108, 25);
            this.lbdate.TabIndex = 10;
            this.lbdate.Text = "Месяц, Год";
            // 
            // taskCards
            // 
            this.taskCards.AutoScroll = true;
            this.taskCards.BackColor = System.Drawing.Color.Transparent;
            this.taskCards.Controls.Add(this.label10);
            this.taskCards.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.taskCards.Location = new System.Drawing.Point(318, 86);
            this.taskCards.Name = "taskCards";
            this.taskCards.Size = new System.Drawing.Size(400, 476);
            this.taskCards.TabIndex = 11;
            this.taskCards.WrapContents = false;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.Location = new System.Drawing.Point(3, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(203, 21);
            this.label10.TabIndex = 64;
            this.label10.Text = "В этот день у вас нет задач";
            // 
            // taskLines
            // 
            this.taskLines.AutoScroll = true;
            this.taskLines.BackColor = System.Drawing.Color.Transparent;
            this.taskLines.Controls.Add(this.label11);
            this.taskLines.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.taskLines.Location = new System.Drawing.Point(5, 86);
            this.taskLines.Name = "taskLines";
            this.taskLines.Size = new System.Drawing.Size(307, 477);
            this.taskLines.TabIndex = 57;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.Location = new System.Drawing.Point(3, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(251, 21);
            this.label11.TabIndex = 65;
            this.label11.Text = "В ближайшие дни у вас нет задач";
            // 
            // labelGreet
            // 
            this.labelGreet.AutoSize = true;
            this.labelGreet.BackColor = System.Drawing.Color.Transparent;
            this.labelGreet.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.labelGreet.ForeColor = System.Drawing.Color.White;
            this.labelGreet.Location = new System.Drawing.Point(4, 7);
            this.labelGreet.Name = "labelGreet";
            this.labelGreet.Size = new System.Drawing.Size(305, 25);
            this.labelGreet.TabIndex = 55;
            this.labelGreet.Text = "Здравствуйте, Степанов Николай!";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.SteelBlue;
            this.panel1.Controls.Add(this.yt_Button2);
            this.panel1.Controls.Add(this.yt_Button1);
            this.panel1.Controls.Add(this.labelGreet);
            this.panel1.ForeColor = System.Drawing.Color.White;
            this.panel1.Location = new System.Drawing.Point(-5, -2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1215, 40);
            this.panel1.TabIndex = 62;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dragForm);
            // 
            // yt_Button2
            // 
            this.yt_Button2.BackColor = System.Drawing.Color.SteelBlue;
            this.yt_Button2.BackColorAdditional = System.Drawing.Color.Gray;
            this.yt_Button2.BackColorGradientEnabled = false;
            this.yt_Button2.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.yt_Button2.BorderColor = System.Drawing.Color.Tomato;
            this.yt_Button2.BorderColorEnabled = false;
            this.yt_Button2.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.yt_Button2.BorderColorOnHoverEnabled = false;
            this.yt_Button2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.yt_Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.yt_Button2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.yt_Button2.ForeColor = System.Drawing.Color.White;
            this.yt_Button2.Location = new System.Drawing.Point(1176, 3);
            this.yt_Button2.Name = "yt_Button2";
            this.yt_Button2.RippleColor = System.Drawing.Color.Black;
            this.yt_Button2.RoundingEnable = false;
            this.yt_Button2.Size = new System.Drawing.Size(35, 38);
            this.yt_Button2.TabIndex = 63;
            this.yt_Button2.Text = "X";
            this.yt_Button2.TextHover = null;
            this.yt_Button2.UseDownPressEffectOnClick = false;
            this.yt_Button2.UseRippleEffect = true;
            this.yt_Button2.UseVisualStyleBackColor = false;
            this.yt_Button2.UseZoomEffectOnHover = false;
            this.yt_Button2.Click += new System.EventHandler(this.yt_Button5_Click);
            // 
            // yt_Button1
            // 
            this.yt_Button1.BackColor = System.Drawing.Color.SteelBlue;
            this.yt_Button1.BackColorAdditional = System.Drawing.Color.Gray;
            this.yt_Button1.BackColorGradientEnabled = false;
            this.yt_Button1.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.yt_Button1.BorderColor = System.Drawing.Color.Tomato;
            this.yt_Button1.BorderColorEnabled = false;
            this.yt_Button1.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.yt_Button1.BorderColorOnHoverEnabled = false;
            this.yt_Button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.yt_Button1.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.yt_Button1.ForeColor = System.Drawing.Color.White;
            this.yt_Button1.Location = new System.Drawing.Point(971, 6);
            this.yt_Button1.Name = "yt_Button1";
            this.yt_Button1.RippleColor = System.Drawing.Color.Black;
            this.yt_Button1.RoundingEnable = false;
            this.yt_Button1.Size = new System.Drawing.Size(175, 30);
            this.yt_Button1.TabIndex = 56;
            this.yt_Button1.Text = "Выход из профиля";
            this.yt_Button1.TextHover = null;
            this.yt_Button1.UseDownPressEffectOnClick = false;
            this.yt_Button1.UseRippleEffect = true;
            this.yt_Button1.UseVisualStyleBackColor = false;
            this.yt_Button1.UseZoomEffectOnHover = false;
            this.yt_Button1.Click += new System.EventHandler(this.yt_Button1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.Location = new System.Drawing.Point(386, 51);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(248, 25);
            this.label9.TabIndex = 63;
            this.label9.Text = "Задачи на выбранную дату";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.Location = new System.Drawing.Point(36, 51);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(234, 25);
            this.label12.TabIndex = 64;
            this.label12.Text = "Задачи в ближайшие дни";
            // 
            // createTask
            // 
            this.createTask.BackColor = System.Drawing.Color.DodgerBlue;
            this.createTask.BackColorAdditional = System.Drawing.Color.Gray;
            this.createTask.BackColorGradientEnabled = false;
            this.createTask.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.createTask.BorderColor = System.Drawing.Color.Tomato;
            this.createTask.BorderColorEnabled = false;
            this.createTask.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.createTask.BorderColorOnHoverEnabled = false;
            this.createTask.Cursor = System.Windows.Forms.Cursors.Hand;
            this.createTask.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.createTask.ForeColor = System.Drawing.Color.White;
            this.createTask.Location = new System.Drawing.Point(724, 521);
            this.createTask.Name = "createTask";
            this.createTask.RippleColor = System.Drawing.Color.Black;
            this.createTask.RoundingEnable = true;
            this.createTask.Size = new System.Drawing.Size(475, 30);
            this.createTask.TabIndex = 59;
            this.createTask.Text = "Создать задачу";
            this.createTask.TextHover = null;
            this.createTask.UseDownPressEffectOnClick = false;
            this.createTask.UseRippleEffect = true;
            this.createTask.UseVisualStyleBackColor = false;
            this.createTask.UseZoomEffectOnHover = false;
            this.createTask.Click += new System.EventHandler(this.createTask_Click);
            // 
            // btnnext
            // 
            this.btnnext.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnnext.BackColorAdditional = System.Drawing.Color.Gray;
            this.btnnext.BackColorGradientEnabled = false;
            this.btnnext.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.btnnext.BorderColor = System.Drawing.Color.Tomato;
            this.btnnext.BorderColorEnabled = false;
            this.btnnext.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.btnnext.BorderColorOnHoverEnabled = false;
            this.btnnext.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnext.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnnext.ForeColor = System.Drawing.Color.White;
            this.btnnext.Location = new System.Drawing.Point(1096, 46);
            this.btnnext.Name = "btnnext";
            this.btnnext.RippleColor = System.Drawing.Color.Black;
            this.btnnext.Rounding = 93;
            this.btnnext.RoundingEnable = true;
            this.btnnext.Size = new System.Drawing.Size(103, 30);
            this.btnnext.TabIndex = 54;
            this.btnnext.Text = "Следующий";
            this.btnnext.TextHover = null;
            this.btnnext.UseDownPressEffectOnClick = false;
            this.btnnext.UseRippleEffect = true;
            this.btnnext.UseVisualStyleBackColor = false;
            this.btnnext.UseZoomEffectOnHover = false;
            this.btnnext.Click += new System.EventHandler(this.calendarButton);
            // 
            // btnprevious
            // 
            this.btnprevious.BackColor = System.Drawing.Color.DodgerBlue;
            this.btnprevious.BackColorAdditional = System.Drawing.Color.Gray;
            this.btnprevious.BackColorGradientEnabled = false;
            this.btnprevious.BackColorGradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal;
            this.btnprevious.BorderColor = System.Drawing.Color.Tomato;
            this.btnprevious.BorderColorEnabled = false;
            this.btnprevious.BorderColorOnHover = System.Drawing.Color.Tomato;
            this.btnprevious.BorderColorOnHoverEnabled = false;
            this.btnprevious.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnprevious.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnprevious.ForeColor = System.Drawing.Color.White;
            this.btnprevious.Location = new System.Drawing.Point(724, 46);
            this.btnprevious.Name = "btnprevious";
            this.btnprevious.RippleColor = System.Drawing.Color.Black;
            this.btnprevious.Rounding = 93;
            this.btnprevious.RoundingEnable = true;
            this.btnprevious.Size = new System.Drawing.Size(103, 30);
            this.btnprevious.TabIndex = 53;
            this.btnprevious.Text = "Прошлый";
            this.btnprevious.TextHover = null;
            this.btnprevious.UseDownPressEffectOnClick = false;
            this.btnprevious.UseRippleEffect = true;
            this.btnprevious.UseVisualStyleBackColor = false;
            this.btnprevious.UseZoomEffectOnHover = false;
            this.btnprevious.Click += new System.EventHandler(this.calendarButton);
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1204, 569);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.createTask);
            this.Controls.Add(this.taskLines);
            this.Controls.Add(this.taskCards);
            this.Controls.Add(this.btnnext);
            this.Controls.Add(this.btnprevious);
            this.Controls.Add(this.lbdate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.daycontainer);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this._10yearsinthejointmadeyouafuckinpussy_Load);
            this.taskCards.ResumeLayout(false);
            this.taskCards.PerformLayout();
            this.taskLines.ResumeLayout(false);
            this.taskLines.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel daycontainer;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lbdate;
        private System.Windows.Forms.FlowLayoutPanel taskCards;
        private yt_DesignUI.yt_Button btnprevious;
        private yt_DesignUI.yt_Button btnnext;
        private System.Windows.Forms.FlowLayoutPanel taskLines;
        private yt_DesignUI.yt_Button createTask;
        private System.Windows.Forms.Label labelGreet;
        private System.Windows.Forms.Panel panel1;
        private yt_DesignUI.yt_Button yt_Button1;
        private yt_DesignUI.yt_Button yt_Button2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
    }
}