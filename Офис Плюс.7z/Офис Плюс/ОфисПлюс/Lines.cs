﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОфисПлюс
{
    public partial class Lines : UserControl
    {
        public Lines()
        {
            InitializeComponent();
        }
        public void values(string taskName, string taskType)
        {
            label1.Text = taskName;
            if (label1.Text.Length > 45)
            {
                label1.Text = label1.Text.Remove(25);
                label1.Text += "...";
            }
            Color color = new Color();
            switch (taskType)
            {
                case "Встреча":
                    color = Color.LightGreen;
                    break;
                case "Совещание":
                    color = Color.Orange;
                    break;
                case "Презентация":
                    color = Color.Red;
                    break;
                case "Выставка":
                    color = Color.Blue;
                    break;
                case "Съезд / Форум":
                    color = Color.LightBlue;
                    break;
                case "Конференция":
                    color = Color.Green;
                    break;
                case "Конгресс":
                    color = Color.DarkRed;
                    break;
                case "Переговоры":
                    color = Color.Gold;
                    break;
                case "Тим - билд":
                    color = Color.DarkCyan;
                    break;
                case "Прочее":
                    color = Color.DarkGray;
                    break;
            }
            panel1.BackColor = color;
        }
    }
}
