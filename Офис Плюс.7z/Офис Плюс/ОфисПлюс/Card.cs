﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ОфисПлюс
{
    public partial class Card : UserControl
    {
        public Card()
        {
            InitializeComponent();
            toolTip1.SetToolTip(this.doneButton, "Выполнить");
            toolTip1.SetToolTip(this.deleteButton, "Удалить");

            Panel pnlTop = new Panel() { Height = 1, Dock = DockStyle.Top, BackColor = Color.Black };
            this.Controls.Add(pnlTop);

            Panel pnlRight = new Panel() { Width = 1, Dock = DockStyle.Right, BackColor = Color.Black };
            this.Controls.Add(pnlRight);

            Panel pnlBottom = new Panel() { Height = 1, Dock = DockStyle.Bottom, BackColor = Color.Black };
            this.Controls.Add(pnlBottom);

            Panel pnlLeft = new Panel() { Width = 1, Dock = DockStyle.Left, BackColor = Color.Black };
            this.Controls.Add(pnlLeft);
        }
        public void values(long id, string taskName, DateTime taskDate, string taskType)
        {
            idLabel.Name = id.ToString();
            labelName.Text = taskName;
            if (labelName.Text.Length > 25)
            {
                labelName.Text = labelName.Text.Remove(25);
                labelName.Text += "...";
            }
            labelDate.Text = "Дата: " + taskDate.ToShortDateString();
            labelType.Text = "Тип: " + taskType;
            switch(taskType)
            {
                case "Встреча":
                    panel1.BackColor = Color.LightGreen;
                    break;
                case "Совещание":
                    panel1.BackColor = Color.Orange;
                    break;
                case "Презентация":
                    panel1.BackColor = Color.Red;
                    break;
                case "Выставка":
                    panel1.BackColor = Color.Blue;
                    break;
                case "Съезд / Форум":
                    panel1.BackColor = Color.LightBlue;
                    break;
                case "Конференция":
                    panel1.BackColor = Color.Green;
                    break;
                case "Конгресс":
                    panel1.BackColor = Color.DarkRed;
                    break;
                case "Переговоры":
                    panel1.BackColor = Color.Gold;
                    break;
                case "Тим - билд":
                    panel1.BackColor = Color.DarkCyan;
                    break;
                case "Прочее":
                    panel1.BackColor = Color.DarkGray;
                    break;
            }
        }
        private void cardButtonClick(object sender, EventArgs e)
        {
            task form = new task();
            task.static_id = Convert.ToInt32(idLabel.Name);
            if (sender as Button == doneButton)
            {
                form.doneButton();
            }
            else
            {
                form.deleteButton();
            }
        }
    }
}
